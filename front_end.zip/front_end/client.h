#ifndef CLIENT_H
#define CLIENT_H

#include <QDialog>
#include <QAbstractSocket>
#include <QObject>

class QTcpSocket;
class QFile;

namespace Ui {
class Client;
}

class Client :public QObject
{
    Q_OBJECT

public:
    explicit Client();
    ~Client();
    void updateImage(QString file_name){
        fileName=file_name;
        if(sendMode/2==0)sendMode+=2;
    }
    void updateWord(QString words_to_send){
        wordsToSend=words_to_send;
        if(sendMode%2==0)sendMode+=1;
    }
    QString getWordData(){
        return wordContent;
    }
    QString getImageData(){
        return imageContent;
    }
    void setName(QString n){
        name=n;
    }
    QString getName(){
        return name;
    }
    void updateWhatToDo(qint64 wtd){
        whatToDo=wtd;
    }
    qint64 getWhatToDo(){
        return whatToDo;
    }
    void getConnected(){
        connectServer();
    }
    void sendOutData(){
        send();
    }
    void getDisconnected(){
        tcpDisconnected();
    }
signals:
    void readMe();

private:
    QTcpSocket *tcpClient;
    QFile *localFile;     // 要发送的文件
    QString name;         //用户名
    qint64 sendMode=0;    // 发送文件的模式，1代表发送文字，2代表发送图片，3代表同时发文字和图片
    qint64 totalBytes;    // 发送数据的总大小
    qint64 bytesReceived=0;  // 已收到数据的大小
    qint64 imageSize;
    qint64 wordSize;
    qint64 whatToDo;
    QString fileName;     // 保存文件路径
    QByteArray outBlock;  // 数据缓冲区，即存放每次要发送的数据块

    QImage image;//图片
    QString currentImageName;//图片名 未用到
    QString wordsToSend;// 任何要发送的文字内容
    QString wordContent;    //文字内容，写出时使用
    QString imageContent;   //图片内容，写出时使用
    volatile bool isOk; //判断是否连上了，以免未连接就调用发送函数


private slots:
//    void openFile();//打开文件
    void send();//发送
    void connectServer();//连接服务器
    void startTransfer();//发送图片数据
    void tcpConnected();//更新isOk的值，按钮以及label的显示
    void tcpDisconnected();//断开连接处理的事件
    void updateClientProgress();//接收并处理显示图片文字
    //图片转base64字符串
    QByteArray getImageData(const QImage&);
    //base64字符串转图片
    QImage getImage(const QString &);

//    void on_openButton_clicked();//打开图片
//    void on_sendButton_clicked();//发送图片
//    void on_connectButton_clicked();//连接或断开服务器
//    void on_sendtext_clicked();//更新要发送的文本
signals:
    void buildConnected();//连接上服务器后，发出的信号
};


#endif // CLIENT_H
