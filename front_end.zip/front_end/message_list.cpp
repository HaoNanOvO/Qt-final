#include "message_list.h"
#include "ui_message_list.h"

message_list::message_list(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::message_list)
{
    ui->setupUi(this);
    ui->textEdit_2->hide();
    ui->textEdit_3->hide();
}

message_list::~message_list()
{
    delete ui;
}
void message_list::showMode(){
    ui->textEdit_2->show();
    ui->textEdit_3->show();
    ui->release_btn->hide();
    ui->label->setText("收到的留言");
}

void message_list::on_release_btn_clicked(){
    ui->release_btn->setText("发送成功！");
    this->close();
}
void message_list::on_back_clicked(){
    this->close();
}
