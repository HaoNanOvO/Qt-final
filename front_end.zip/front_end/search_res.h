#ifndef SEARCH_RES_H
#define SEARCH_RES_H

#include <QWidget>
#include "client.h"

//感觉用不上这个界面了，和search一起就行了
namespace Ui {
class search_res;
}

class search_res : public QWidget
{
    Q_OBJECT

public:
    explicit search_res(Client* c,QWidget *parent = nullptr);
    ~search_res();

private:
    Ui::search_res *ui;
    Client *client;
};

#endif // SEARCH_RES_H
