#ifndef SEARCH_H
#define SEARCH_H

#include <QMainWindow>
#include "client.h"
#include "search_res.h"
#include "message_list.h"
//加了展示图文的label各1，但没做点进去聊天/发消息的按钮？我自己做了
namespace Ui {
class search;
}

class search : public QMainWindow
{
    Q_OBJECT

public:
    explicit search(Client* c,QWidget *parent = nullptr);
    ~search();

private:
    Ui::search *ui;
    Client *client;
    search_res *srr;
    message_list *ms;
    QImage getImage(const QString &data)
    {
        QByteArray imageData = QByteArray::fromBase64(data.toLatin1());
        QImage image;
        image.loadFromData(imageData);
        return image;
    }
    void messageSend();
private slots:
    void on_search_btn_clicked();
    void on_back_btn_clicked();
    void on_cancel_btn_2_clicked();
    void on_message_btn_clicked();
    void on_message_btn_2_clicked();
    void showResults();
};

#endif // SEARCH_H
