#include "goods_show.h"
#include "ui_goods_show.h"
#include "mainwindows.h"
#include <QFile>
goods_show::goods_show(Client* c,QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::goods_show)
    , client(c)
{
    ui->setupUi(this);
    mainwindows::setStyle(":/goods_show.qss");
    connect(client,SIGNAL(readMe()),this,SLOT(showResults()));
    client->updateWhatToDo(5);
    client->sendOutData();
}

goods_show::~goods_show()
{
    delete ui;
}

void goods_show::on_back_clicked(){
    this->close();
}

void goods_show::showResults(){
    qDebug()<<"收到readMe";
    if(1){
        ui->textBrowser->show();
        ui->imageLabel->show();
        ui->price->setText("123");
        ui->textBrowser->setText(client->getWordData());
        //图片适应显示器，完全来自csdn,少碰
        QImage imageData = getImage(client->getImageData());
        QPixmap resImage = QPixmap::fromImage(imageData);
        QPixmap* imgPointer = &resImage;
        imgPointer->scaled(ui->imageLabel->size(), Qt::IgnoreAspectRatio);//重新调整图像大小以适应窗口
        // imgPointer->scaled(ui->imageLabel->size(), Qt::KeepAspectRatio);//设置pixmap缩放的尺寸
        ui->imageLabel->setScaledContents(true);//设置label的属性,能够缩放pixmap充满整个可用的空间。
        ui->imageLabel->setPixmap(*imgPointer);
    }
}

