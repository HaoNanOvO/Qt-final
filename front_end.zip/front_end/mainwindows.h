#ifndef MAINWINDOWS_H
#define MAINWINDOWS_H

#include <QWidget>
#include "client.h"
#include "search.h"
#include "release.h"
#include "message_list.h"
#include "goods_show.h"
namespace Ui {
class mainwindows;
}

class mainwindows : public QWidget
{
    Q_OBJECT

public:
    explicit mainwindows(Client* c,QWidget *parent = nullptr);
    ~mainwindows();
    static void setStyle(const QString &styleName);

private:
    Ui::mainwindows *ui;
    Client* client;
    search* sr;
    release* rl;
    message_list *ms;
    goods_show *gd;
private slots:
    void on_searching_clicked();
    void on_adding_clicked();
    void on_Profile_clicked();
    void on_Message_clicked();
    void on_search_edit_cursorPositionChanged(int arg1, int arg2);
};

#endif // MAINWINDOWS_H
