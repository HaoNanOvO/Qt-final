#ifndef MESSAGE_LIST_H
#define MESSAGE_LIST_H

#include <QWidget>

namespace Ui {
class message_list;
}

class message_list : public QWidget
{
    Q_OBJECT

public:
    explicit message_list(QWidget *parent = nullptr);
    ~message_list();
    void showMode();

private:
    Ui::message_list *ui;
private slots:
    void on_back_clicked();

    void on_release_btn_clicked();
};

#endif // MESSAGE_LIST_H
