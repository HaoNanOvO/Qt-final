#ifndef LOGIN_H
#define LOGIN_H

#include <QMainWindow>
#include "client.h"
#include "mainwindows.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class login;
}
QT_END_NAMESPACE

class login : public QMainWindow
{
    Q_OBJECT

public:
    login(Client* c,QWidget *parent = nullptr);
    ~login();
    void setStyle(const QString &styleName);

private slots:
    void on_Login_clicked();
    void validLogin();
    void on_SignIn_clicked();

private:
    Ui::login *ui;
    Client* client;
    mainwindows* m;
    QString name;
    QString password;
};
#endif // LOGIN_H
