#include "mainwindows.h"
#include <QFile>
#include "ui_mainwindows.h"
void mainwindows::setStyle(const QString &styleName)
{
    QFile file(QString("%1").arg(styleName));
    file.open(QFile::ReadOnly);
    QTextStream filetext(&file);
    QString qss=filetext.readAll();
    qApp->setStyleSheet(qss);
}
mainwindows::mainwindows(Client *c,QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::mainwindows)
    , client(c)
{
    ui->setupUi(this);
    setStyle(":/mainwindow.qss");
}

mainwindows::~mainwindows()
{
    delete ui;
}

void mainwindows::on_searching_clicked(){
    sr = new search(client);
    sr->show();
}
void mainwindows::on_adding_clicked(){
    rl = new release(client);
    rl->show();
}
void mainwindows::on_Profile_clicked(){
    gd = new goods_show(client);
    gd->show();
}
void mainwindows::on_Message_clicked(){
    ms = new message_list();
    ms->showMode();
    ms->show();
}


