#include "search.h"
#include "ui_search.h"
#include <QFile>
#include "mainwindows.h"

search::search(Client* c,QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::search)
    , client(c)
{
    ui->setupUi(this);
    mainwindows::setStyle(":/search.qss");
    ui->imageLabel->hide();
    ui->textBrowser->hide();
    ui->message_btn->hide();
    ui->priceBrowser->hide();
    ui->imageLabel_2->hide();
    ui->textBrowser_2->hide();
    ui->message_btn_2->hide();
    ui->priceBrowser_2->hide();
    ui->label->hide();
    ui->label_2->hide();
    ui->label_3->hide();
    ui->label_4->hide();
    connect(client,SIGNAL(readMe()),this,SLOT(showResults()));
}

search::~search()
{
    delete ui;
}

void search::on_search_btn_clicked(){
    client->updateWord(ui->search_edit->text());
    client->updateWhatToDo(3);
    client->sendOutData();
}

void search::on_back_btn_clicked(){
    this->close();
}

void search::on_cancel_btn_2_clicked(){
    ui->search_edit->setText("");
}
void search::on_message_btn_clicked(){
    messageSend();
}
void search::on_message_btn_2_clicked(){
    messageSend();
}
void search::messageSend(){
    ms = new message_list();
    ms->show();
}
//只展示了两个
void search::showResults(){
    qDebug()<<"收到readMe";
    if(client->getWhatToDo() == 101){
    ui->textBrowser->show();
    ui->imageLabel->show();
    ui->message_btn->show();
    ui->priceBrowser->show();
    ui->label->show();
    ui->label_2->show();
    QString rawData=client->getWordData();
    ui->priceBrowser->setText(rawData.section('/',2,2));
    ui->textBrowser->setText(rawData.section('/',3,3));
    //图片适应显示器，完全来自csdn,少碰
    QImage imageData = getImage(client->getImageData());
    QPixmap resImage = QPixmap::fromImage(imageData);
    QPixmap* imgPointer = &resImage;
    imgPointer->scaled(ui->imageLabel->size(), Qt::IgnoreAspectRatio);//重新调整图像大小以适应窗口
    // imgPointer->scaled(ui->imageLabel->size(), Qt::KeepAspectRatio);//设置pixmap缩放的尺寸
    ui->imageLabel->setScaledContents(true);//设置label的属性,能够缩放pixmap充满整个可用的空间。
    ui->imageLabel->setPixmap(*imgPointer);
    }
    else if(client->getWhatToDo() == 102){
        ui->textBrowser_2->show();
        ui->imageLabel_2->show();
        ui->message_btn_2->show();
        ui->label_3->show();
        ui->label_4->show();
        ui->textBrowser_2->setText(client->getWordData());
        //图片适应显示器，完全来自csdn,少碰
        QImage imageData = getImage(client->getImageData());
        QPixmap resImage = QPixmap::fromImage(imageData);
        QPixmap* imgPointer = &resImage;
        imgPointer->scaled(ui->imageLabel_2->size(), Qt::IgnoreAspectRatio);//重新调整图像大小以适应窗口
        // imgPointer->scaled(ui->imageLabel->size(), Qt::KeepAspectRatio);//设置pixmap缩放的尺寸
        ui->imageLabel_2->setScaledContents(true);//设置label的属性,能够缩放pixmap充满整个可用的空间。
        ui->imageLabel_2->setPixmap(*imgPointer);
    }
}
