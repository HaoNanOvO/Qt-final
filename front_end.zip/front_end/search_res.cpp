#include "search_res.h"
#include "ui_search_res.h"
#include "mainwindows.h"
#include <QFile>

search_res::search_res(Client* c,QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::search_res)
    , client(c)
{
    ui->setupUi(this);
    mainwindows::setStyle(":/search_res.qss");

}

search_res::~search_res()
{
    delete ui;
}
