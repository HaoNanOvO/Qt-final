#include "login.h"
#include "search.h"
#include "mainwindows.h"
#include "search_res.h"
#include "goods_show.h"
#include "release.h"
#include "client.h"
#include <QFile>
#include <QTextStream>
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Client* client = new Client();
    login w(client);
    w.show();
    return a.exec();
}
