#include "login.h"
#include "ui_login.h"
#include <QLineEdit>
#include <QFile>
void login::setStyle(const QString &styleName)
{
    QFile file(QString("%1").arg(styleName));
    file.open(QFile::ReadOnly);
    QTextStream filetext(&file);
    QString qss=filetext.readAll();
    qApp->setStyleSheet(qss);
    ui->textBrowser->hide();
}
login::login(Client* c,QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::login)
    , client(c)
{
    ui->setupUi(this);
    setStyle(":/login.qss");
    ui->input2->setEchoMode(QLineEdit::Password);
    connect(client,SIGNAL(readMe()),this,SLOT(validLogin()));
}

login::~login()
{
    delete ui;
}

void login::on_Login_clicked()
{
    qDebug()<<"clicked";
    client->getConnected();
    name = ui->input1->text();
    password = ui->input2->text();
    client->updateWord(name+"/"+password);
    client->updateWhatToDo(1);
    client->sendOutData();
}

void login::on_SignIn_clicked(){
    client->getConnected();
    name = ui->input1->text();
    password = ui->input2->text();
    client->updateWord(name+"/"+password);
    client->updateWhatToDo(4);
    client->sendOutData();

//    _sleep(100);client->getDisconnected();
}

void login::validLogin(){

    qDebug()<<"receive readMe()";
    qDebug()<<client->getWhatToDo();
    if(client->getWhatToDo() == 101){
        client->setName(name);
//        mainwindows m(client);
        m = new mainwindows(client);
        m->show();
        disconnect(client,SIGNAL(readMe()),this,SLOT(validLogin()));
        this->close();
    }
    else if(client->getWhatToDo() == 102){
        ui->textBrowser->show();
        ui->textBrowser->setText("不合法的登录");
    }
    else if(client->getWhatToDo() == 103){
        ui->textBrowser->show();
        ui->textBrowser->setText("注册成功！");
    }
    else if(client->getWhatToDo() == 104){
        ui->textBrowser->show();
        ui->textBrowser->setText("该用户名已被占用");
    }
}

