#ifndef RELEASE_H
#define RELEASE_H

#include <QWidget>
#include "client.h"
namespace Ui {
class release;
}

class release : public QWidget
{
    Q_OBJECT

public:
    explicit release(Client *c,QWidget *parent = nullptr);
    ~release();

private:
    Ui::release *ui;
    Client* client;
    QString nm;
    QString pr;
    QString ds;
    QString fileName;
private slots:
    void on_release_btn_clicked();
    void on_photo_add_clicked();
    void on_back_btn_clicked();
};

#endif // RELEASE_H
