#include "release.h"
#include "ui_release.h"
#include <QFileDialog>

release::release(Client* c,QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::release)
    , client(c)
{
    ui->setupUi(this);
}

release::~release()
{
    delete ui;
}
void release::on_release_btn_clicked(){
    nm = ui->itemName->text();
    pr = ui->price->text();
    ds = ui->description->text();
    client->updateWord(client->getName()+"/"+nm+"/"+pr+"/"+ds);
    client->updateImage(fileName);
    client->updateWhatToDo(2);
    client->sendOutData();
    this->close();
}

void release::on_photo_add_clicked()
{
    fileName = QFileDialog::getOpenFileName(this);
    if(!fileName.isEmpty())ui->photo_add->setText("添加成功！");
}

void release::on_back_btn_clicked(){
    this->close();
}

