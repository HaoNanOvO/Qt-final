#include "client.h"

#include <QtNetwork>
#include <QFileDialog>
#include <QCompleter>


Client::Client()
{   


//    payloadSize = 64 * 1024; // 64KB
    totalBytes = 0;
    isOk = false;
    
    tcpClient = new QTcpSocket();

    // 当连接服务器成功时，发出connected()信号，isOK置为true
    connect(tcpClient, SIGNAL(connected()), this, SLOT(tcpConnected()));

    //当点击发送按钮后(且isOK为true)，发出buildConnected()信号，开始传送数据
    connect(this, SIGNAL(buildConnected()), this, SLOT(startTransfer()));

    //当断开连接时，发出disconnected(),isOK置为false
    connect(tcpClient, SIGNAL(disconnected()), this, SLOT(tcpDisconnected()));

    //当服务器端发出readyread信号时，接收信息
    connect(tcpClient, SIGNAL(readyRead()),this,SLOT(updateClientProgress()));

}

Client::~Client()
{

}
/*
void Client::openFile()
{
    fileName = QFileDialog::getOpenFileName(this);
    
    if (!fileName.isEmpty()) {
        
        //获得实际文件名
        currentImageName = fileName.right(fileName.size()
                                                 - fileName.lastIndexOf('/')-1);

        ui->clientStatusLabel->setText(tr("打开 %1 文件成功！").arg(currentImageName));
        if(sendMode<2)sendMode+=2;
        if(isOk == true){
            ui->sendButton->setEnabled(true);
        }
    }
}
*/
void Client::send()
{
    if(!isOk){
        qDebug()<<"未连接服务器";
        return;
    }else{
        //发射信号
        emit buildConnected();
        qDebug() << "emit buildConnected()\n";
    }
}

void Client::connectServer()
{
    // 初始化已发送字节为0
//    bytesWritten = 0;

//    //连接到服务器
    //tcpClient->connectToHost(ui->hostLineEdit->text(),ui->portLineEdit->text().toInt());
    tcpClient->connectToHost(QHostAddress("127.0.0.1"),6666);
    qDebug("State:%d\n",tcpClient->state());
    tcpClient->waitForConnected(1000);
    qDebug("State:%d\n",tcpClient->state());
    if(tcpClient->state()==3){
    isOk = true;
        qDebug() << "connectServer: isOk is ok\n";}
}


void Client::startTransfer()
{
    qDebug("State:%d\n",tcpClient->state());//这是看连接状态的，为调试代码

    QDataStream sendOut(&outBlock, QIODevice::WriteOnly);
    sendOut.setVersion(QDataStream::Qt_5_6);

    QByteArray wordData;
    QString imageData;

    //获得文字信息
    if(sendMode%2 ==1){
        wordData=wordsToSend.toUtf8();
        qDebug()<<wordData;
    }

   //获得图片数据
    if(sendMode/2 ==1){
    QImage image(fileName);
    imageData = getImageData(image);
    }

//    qDebug() << "fileName: " <<fileName << "\n";

    
    // 保留模式信息空间、总大小信息空间、文字大小信息空间、图像大小信息空间；没有则为0
    sendOut << qint64(0)<< qint64(0) << qint64(0) << qint64(0)<< qint64(0)<<wordData<<imageData;
    //写出图文信息
    qDebug()<<wordData.size()<<imageData.size();


    totalBytes = outBlock.size();
    sendOut.device()->seek(0);

    // 返回outBolock的开始，用实际的大小信息代替四个qint64(0)空间
    sendOut << whatToDo <<sendMode <<totalBytes << qint64(wordData.size()) << qint64(2*(imageData.size()));
    qDebug()<< whatToDo <<sendMode <<totalBytes << qint64(wordData.size()) << qint64(2*(imageData.size()));
    //发出readyRead（）信号
    tcpClient->write(outBlock);


    outBlock.resize(0);

    totalBytes = 0;
    sendMode = 0;
    _sleep(200);
    tcpClient->readAll();
//    bytesToWrite = 0;
}


void Client::updateClientProgress()
{
    //qDebug()<<"服务器接收";
    QDataStream in(tcpClient);
    in.setVersion(QDataStream::Qt_5_6);
    //qDebug()<<tcpClient->bytesAvailable();
    // 如果接收到的数据小于40个字节，保存到来的文件头结构
    if (bytesReceived <= sizeof(qint64)*5) {
        if((tcpClient->bytesAvailable() >= sizeof(qint64)*5)&&(bytesReceived==0))
             {
            // 接收数据总大小信息和文件名大小信息
            in >>whatToDo >>sendMode >> totalBytes >> wordSize >> imageSize;
            bytesReceived += sizeof(qint64) * 5;

            qDebug() <<whatToDo<<sendMode<<" "<<totalBytes<<" "<<wordSize<<" "<< imageSize;
            qDebug() <<"定位点0\n";
        }

        if((tcpClient->bytesAvailable() >= imageSize+ wordSize -100))
        {

            // 接收文件名，并建立文件
            qDebug() <<sendMode<<" "<<totalBytes<<" "<<wordSize<<" "<< imageSize;
            char BYTE;
            for(int i=0;i<4;i++)in>>BYTE; //一定要读掉四个字节，大概是QString类的一部分
            if(wordSize!=0){
                QByteArray tmpwordContent;
                for(qint64 tmpsize=0;tmpsize<wordSize;tmpsize++){
                    in>>BYTE;
                    tmpwordContent.append(BYTE);
                }
                wordContent=QString::fromUtf8(tmpwordContent);
                bytesReceived += wordSize;
            }
            if(imageSize!=0){

                in>>imageContent;

                bytesReceived += imageContent.size()*2;
            }
            bytesReceived += 8;

            qDebug() << "定位1  bytesReceived: " << bytesReceived << "\n";

            if(bytesReceived == totalBytes){
                qDebug()<<"成功";
            }
                totalBytes = 0;
                bytesReceived = 0;
                imageSize = 0;
                wordSize = 0;
                sendMode = 0;
                tcpClient->readAll();
                emit readMe();
                qDebug()<<"emit readMe()";
        }
    }
}


void Client::tcpConnected()
{
    isOk = true;
}
void Client::tcpDisconnected()
{
    isOk = false;
    tcpClient->abort();

}
//目前默认是png格式的图片，要发其他格式的应该是只需要改save函数里那个"png"就行了，但还未试过
QByteArray Client::getImageData(const QImage &image)
{
    QByteArray imageData;
    QBuffer buffer(&imageData);
    image.save(&buffer, "png");
    imageData = imageData.toBase64();
    return imageData;
}

QImage Client::getImage(const QString &data)
{
    QByteArray imageData = QByteArray::fromBase64(data.toLatin1());
    QImage image;
    image.loadFromData(imageData);
    return image;
}
//下面这些仅供参考，具体按照实际ui写交互逻辑

