#ifndef GOODS_SHOW_H
#define GOODS_SHOW_H

#include <QWidget>
#include "client.h"
namespace Ui {
class goods_show;
}

class goods_show : public QWidget
{
    Q_OBJECT

public:
    explicit goods_show(Client* c,QWidget *parent = nullptr);
    ~goods_show();

private:
    Ui::goods_show *ui;
    Client* client;
    QImage getImage(const QString &data)
    {
        QByteArray imageData = QByteArray::fromBase64(data.toLatin1());
        QImage image;
        image.loadFromData(imageData);
        return image;
    }
private slots:
    void on_back_clicked();
    void showResults();
};

#endif // GOODS_SHOW_H
