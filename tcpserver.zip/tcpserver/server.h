#ifndef SERVER_H
#define SERVER_H

#include <QDialog>
#include <QAbstractSocket>
#include <QObject>
#include <QTcpServer>
#include<QDir>
#include<QFile>
#include<QMessageBox>
#include<QString>
#include <QByteArray>
#include <QTextStream>
#include <QDataStream>
#include <QIODevice>
#include <QMap>
#include <QHash>
#include <QList>
#include <QStringList>
#include <QDebug>

class QTcpSocket;
class QFile;

namespace Ui {
class Server;
}

class Server : public QDialog
{
    Q_OBJECT

public:
    explicit Server(QWidget *parent = 0);
    ~Server();

private:
    Ui::Server *ui;

    QTcpServer tcpServer;
    QTcpSocket *tcpServerConnection;
    qint64 totalBytes;     // 存放总大小信息
    qint64 bytesReceived;  // 已收到数据的大小
//    qint64 fileNameSize;   // 文件名的大小信息
    qint64 imageSize; //图片大小
    qint64 wordSize;  //文字大小

    qint64 sendMode; //发送模式,0是什么都不发，1发文字，2发图片，3都发

    qint64 whatToDo; //告诉你要做什么，1发送账号密码，只收到文字；2是上传商品，一图一文；3检索，只收到文字

    QString fileName;      // 存放文件名
    QFile *localFile;      // 本地文件
    QByteArray inBlock;    // 数据缓冲区
    QByteArray outBlock;

    QString wordContent;    //文字内容，接收时使用
    QString imageContent;   //图片内容，接收时使用

    QImage image;//图片，暂存用
    QString wordsToSend;// 任何要发送的文字内容



private slots:

    void start();//监听的事件
    void acceptConnection();//被客户端连接上后，创建套接字、接收数据、处理异常、关闭服务器
    void updateServerProgress();//接收并处理显示图片文字
    void startTransfer();//向客户端写入信息

//    void displayError(QAbstractSocket::SocketError socketError);//错误处理

    //图片转base64字符串
    QByteArray getImageData(const QImage&);
    //base64字符串转图片
    QImage getImage(const QString &);

    void on_startButton_clicked();//监听或断开监听
    //void on_send_btn_clicked();
signals:
     void serverLogin();
};

inline int save_nameandpassword(QString owner_name,QString password) //保存用户名字和密码，成功返回0，用户名重复返回1，其他原因返回2
{
    qDebug()<<"save called";
    QDir *file=new QDir;
    bool isexist=file->exists("data");
    if(!isexist){file->mkdir("data");}      //创建data文件夹保存用户信息
    isexist=file->exists("data\\"+owner_name);    //判断用户名是否重复，重复返回1
    if(isexist){return 1;
        QFile f("data\\"+owner_name+"\\password");
        f.open(QIODevice::WriteOnly);
        f.resize(0);
        f.write(password.toUtf8());
        f.close();
    }else{
        bool ismk=file->mkpath("data\\"+owner_name);   //创建以用户名命名的文件夹保存用户信息
        if(ismk){   //判断是否创建成功，失败返回2（未知原因，可能是超过储存上限了）
            QFile f("data\\"+owner_name+"\\password");
            f.open(QIODevice::WriteOnly);
            f.write(password.toUtf8());
            f.close();
        }else{return 2;}
    }
    return 0;
}

inline int querry_password(QString owner_name,QString password){   //登录时匹配用，成功返回0，密码错误返回1，用户名不存在返回2
    qDebug()<<"q called";
    QDir *file=new QDir;
    bool isexist=file->exists("data\\"+owner_name);     //判断用户名
    if(!isexist)return 2;
    QFile f("data\\"+owner_name+"\\password");
    f.open(QIODevice::ReadOnly);          //登录输入的存放在ba，数据库里的存放在bba
    QByteArray s=f.readAll();
    QByteArray p=password.toUtf8();
    f.close();
    if(s==p)return 0;    //判断密码
    else return 1;
}

inline int save_shangpin(QString owner_name,QString shangpin_name,QString shangpin_info,
                         float shangpin_price, QByteArray shangpin_image) //注册时保存信息用，成功返回0，重复保存返回1，其他失败原因返回2
{

    QDir dir("data\\"+owner_name+"\\"+shangpin_name);//判断重复商品
    bool isexist=dir.exists();
    if(isexist)return 1;
    bool ismk=dir.mkpath("data\\"+owner_name+"\\"+shangpin_name);

    QFile f_searchlist("data\\searchlist");   //维护搜索信息
    f_searchlist.open(QIODevice::Append|QIODevice::Text);
    QTextStream out(&f_searchlist);
    out<<shangpin_name<<"\n";
    out<<owner_name<<"\n";

    if(ismk){   //判断是否创建成功，失败返回2（未知原因，可能是超过储存上限了）
        QFile f("data\\"+owner_name+"\\"+shangpin_name+"\\shangpin_info"); //保存商品描述信息
        f.open(QIODevice::WriteOnly);
        f.write(shangpin_info.toUtf8());
        f.close();

        QFile fff("data\\"+owner_name+"\\"+shangpin_name+"\\shangpin_price"); //保存商品价格
        fff.open(QIODevice::WriteOnly);
        QDataStream outt(&fff);
        outt.setVersion(QDataStream::Qt_5_6);
        outt<<shangpin_price;
        fff.close();

        QFile ff("data\\"+owner_name+"\\"+shangpin_name+"\\shangpin_image"); //保存商品图片信息
        ff.open(QIODevice::WriteOnly);
        ff.write(QByteArray::fromBase64(shangpin_image));
        ff.close();
    }else{return 2;}
    return 0;
}

inline int delete_shangpin(QString owner_name,QString shangpin_name) {//输入要删除的商品名字，成功返回0，不存在的商品返回1，无法打开返回2
    QDir dir("data\\"+owner_name+"\\"+shangpin_name);//判断是否存在
    int isexist=dir.exists();
    if(!isexist)return 1;

    QFile originalFile("data\\searchlist");     //维护搜索列表
    QFile tempFile("data\\temp_file.tmp");

    // 打开原始文件以供读取
    if (!originalFile.open(QIODevice::ReadOnly)) {
        qDebug() << "无法打开原始文件";
        return  2;
    }

    // 创建临时文件以供写入
    if (!tempFile.open(QIODevice::WriteOnly)) {
        qDebug() << "无法创建临时文件";
        originalFile.close();
        return 2;
    }

    QTextStream in(&originalFile);
    QTextStream out(&tempFile);
    QString line;
    // 逐行读取原始文件
    while (in.readLineInto(&line)) {
        // 去除每行的首尾空白字符
        QString trimmedLine = line.trimmed();
        // 与去除空白后的要删除的行进行比较
        if (trimmedLine != shangpin_name) {
            // 如果当前行不是要删除的行，则写入临时文件
            out << line<<"\n"; // 写入原始行，包括可能的首尾空格
        }else{
            in.readLineInto(&owner_name);
        }
    }

    // 关闭文件
    originalFile.close();
    tempFile.close();

    // 用临时文件替换原始文件
    if (QFile::remove("data\\searchlist") && tempFile.rename("data\\searchlist")) {
        //qDebug() << "文件更新成功";
    } else {
        //qDebug() << "更新文件失败";
    }

    dir.removeRecursively();
    return 1;
}

inline int maxLength(const QString &str1, const QString &str2) {   //子串匹配函数
    int length1 = str1.length();
    int length2 = str2.length();
    std::vector<std::vector<int>> dp(length1 + 1, std::vector<int>(length2 + 1, 0));
    int maxLength = 0;

    for (int i = 1; i <= length1; ++i) {
        for (int j = 1; j <= length2; ++j) {
            if (str1[i - 1] == str2[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1] + 1;
                maxLength = std::max(maxLength, dp[i][j]);
            }
        }
    }

    return maxLength;
}


inline QList<std::pair<QString, QString>> keywordsearch(const QString searchword) {//关键词搜索，成功返回QList<商品名，卖家>，失败返回空QList<std::pair<QString, QString>>
    QFile file("data\\searchlist");
    QMap<QString, QString> nameToIdMap;
    QString currentName;

    // 打开文件以供读取
    if (!file.open(QIODevice::ReadOnly)) {
        qDebug() << "无法打开文件";
        return QList<std::pair<QString, QString>>();
    }

    QTextStream in(&file);
    QString line;
    while (in.readLineInto(&line)) {
        // 跳过空行
        if (line.isEmpty()) {
            continue;
        }
        if (currentName.isEmpty()) {
            // 第一行，存储名字
            currentName = line;
        } else {
            // 第二行，存储编号
            nameToIdMap.insert(currentName, line);
            currentName.clear();
        }
    }
    file.close();

    //debug用，查看是否读入
    //for (auto it = nameToIdMap.begin(); it != nameToIdMap.end(); ++it) {qDebug() << "商品名:" << it.key() << ",卖家:" << it.value()<<Qt::endl;}

    //子串匹配

    QList<std::pair<QString, QString>> matches;
    int maxSubstringLength = 0;

    for (auto it = nameToIdMap.constBegin(); it != nameToIdMap.constEnd(); ++it) {
        int currentLength = maxLength(it.key(), searchword);
        if (currentLength > maxSubstringLength) {
            maxSubstringLength = currentLength;
            matches.clear();
            matches.append({it.key(), it.value()});
        } else if (currentLength == maxSubstringLength) {
            matches.append({it.key(), it.value()});
        }
    }


    // 输出结果
    for (const auto &match : matches) {
        qDebug() << "商品名:" << match.first << ",卖家:" << match.second;
    }

    return matches;
}

class shangpin{
public:QString shangpin_name;    //商品名字
    QString shangpin_info;   //文字描述信息
    QString owner_name;  //主人的名字
    QString shangpin_image_location;   //图片地址
    float shangpin_price;    //价格
    int isexist;    //1表示存在，0表示不存在
    shangpin(QString sn,QString in,QString on,QString im,qfloat16 p){
        shangpin_name=sn;shangpin_info=in;owner_name=on;shangpin_image_location=im;shangpin_price=p;isexist=1;
    }
    shangpin(){isexist=0;}
};

inline shangpin querry_shangpin(QString owner_name,QString shangpin_name){//查询商品，成功返回临时对象，失败返回空，可通过成员isexist判断
    QDir dir("data\\"+owner_name+"\\"+shangpin_name);
    int isexist=dir.exists();
    if(!isexist)return shangpin();

    QString shangpin_info;   //文字描述信息
    float shangpin_price;    //价格

    QFile f("data\\"+owner_name+"\\"+shangpin_name+"\\shangpin_info"); //查询商品描述信息
    f.open(QIODevice::ReadOnly);
    QByteArray tmp = f.readAll();
    shangpin_info = QString::fromUtf8(tmp.data());
    qDebug()<<shangpin_info<<owner_name;
    f.close();

    QFile fff("data\\"+owner_name+"\\"+shangpin_name+"\\shangpin_price"); //查询商品价格
    fff.open(QIODevice::ReadOnly);
    QDataStream in(&fff);
    in.setVersion(QDataStream::Qt_5_6);
    in>>shangpin_price;
    qDebug()<<shangpin_price<<owner_name;
    fff.close();

    return shangpin(shangpin_name,shangpin_info,owner_name,"data\\"+owner_name+"\\"+shangpin_name+"\\shangpin_image",shangpin_price);
}


#endif // SERVER_H
