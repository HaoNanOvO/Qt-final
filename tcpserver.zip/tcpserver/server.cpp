#include "server.h"
#include "ui_server.h"

#include <QtNetwork>
#include <QCompleter>

Server::Server(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Server)
{
    ui->setupUi(this);

    //端口自动补全以及默认提示
    ui->portLineEdit->setText(tr("6666"));//设置默认提示
    QStringList portWordList;
    portWordList << tr("6666");
    QCompleter* portCompleter = new QCompleter(portWordList, this);
    ui->portLineEdit->setCompleter(portCompleter);


    connect(&tcpServer, SIGNAL(newConnection()),
            this, SLOT(acceptConnection()));




    ui->imageLabel->show();

    qDebug() << "pl1\n";
}

Server::~Server()
{
    delete ui;
}

//地址理论上可以改，没有条件测试，推荐还是在127.0.0.1（即本机）
void Server::start()
{
    tcpServer.listen(QHostAddress("127.0.0.1"), ui->portLineEdit->text().toInt());
    qDebug()<<ui->portLineEdit->text().toInt();
    /*if (!tcpServer.listen(QHostAddress::LocalHost, ui->portLineEdit->text().toInt())) {
        qDebug() << tcpServer.errorString();
        close();
        return;
    }*/

    totalBytes = 0;
    bytesReceived = 0;
    imageSize = 0;
    ui->serverStatusLabel->setText(tr("正在监听"));
    qDebug()<<tcpServer.serverAddress()<<"\n";
    //tcpServer.waitForNewConnection(10000);
    qDebug() << "pl0\n";
}

void Server::acceptConnection()
{
    //获得链接套接字
    tcpServerConnection = tcpServer.nextPendingConnection();
    qDebug() << "pl2\n";
    //接收数据
    //readyRead()当网络套接字上有新的网络数据有效负载时
    connect(tcpServerConnection, SIGNAL(readyRead()),
            this, SLOT(updateServerProgress()));
    //处理异常
    //    connect(tcpServerConnection, SIGNAL(error(QAbstractSocket::SocketError)),
    //            this, SLOT(displayError(QAbstractSocket::SocketError)));

    ui->serverStatusLabel->setText(tr("接受连接"));
    // 关闭服务器，不再进行监听
    //    tcpServer.close();
}


void Server::updateServerProgress()
{
    QDataStream in(tcpServerConnection);
    in.setVersion(QDataStream::Qt_5_6);
    // 如果接收到的数据小于40个字节，保存到来的文件头结构
    if (bytesReceived <= sizeof(qint64)*5) {
        if((tcpServerConnection->bytesAvailable() >= sizeof(qint64)*5)
            && (imageSize == 0)) {
            // 接收数据总大小信息和文件名大小信息
            in >>whatToDo >>sendMode >> totalBytes >> wordSize >> imageSize;
            bytesReceived += sizeof(qint64) * 5;

            if(imageSize == 0){
                ui->serverStatusLabel->setText(tr("显示的图片为空!"));
            }
            qDebug() <<"定位点0\n";
        }
        qDebug()<<whatToDo<<sendMode<<totalBytes<<wordSize<<imageSize;
        qDebug()<<tcpServerConnection->bytesAvailable();
        if((tcpServerConnection->bytesAvailable() >= imageSize + wordSize - 100))
        {

            // 接收文件名，并建立文件
            qDebug() <<sendMode<<" "<<totalBytes<<" "<<wordSize<<" "<< imageSize;
            char BYTE;
            for(int i=0;i<4;i++)in>>BYTE;//读掉四位，应该是QString类的一部分
            if(wordSize!=0){
                QByteArray tmpwordContent;


                for(qint64 tmpsize=0;tmpsize<wordSize;tmpsize++){
                    in>>BYTE;
                    tmpwordContent.append(BYTE);
                }
                wordContent=QString::fromUtf8(tmpwordContent);
                bytesReceived += wordSize;
            }

            //    for(int i=0;i<4;i++)in>>BYTE;

            if(imageSize!=0){

                in>>imageContent;
                qDebug()<<imageContent.size()*2;
                bytesReceived += imageContent.size()*2;
            }
            bytesReceived += 8;

            ui->serverStatusLabel->setText(tr("接收文件 …"));

            ui->textBrowser->setText(wordContent);
            //图片适应显示器，完全来自csdn,少碰
            QImage imageData = getImage(imageContent);

            QPixmap resImage = QPixmap::fromImage(imageData);
            QPixmap* imgPointer = &resImage;
            imgPointer->scaled(ui->imageLabel->size(), Qt::IgnoreAspectRatio);//重新调整图像大小以适应窗口
            // imgPointer->scaled(ui->imageLabel->size(), Qt::KeepAspectRatio);//设置pixmap缩放的尺寸

            ui->imageLabel->setScaledContents(true);//设置label的属性,能够缩放pixmap充满整个可用的空间。
            ui->imageLabel->setPixmap(*imgPointer);


            qDebug() << "定位1  bytesReceived: " << bytesReceived << "\n";

            if(bytesReceived == totalBytes){
                ui->serverStatusLabel->setText(tr("接收文件成功"));
            }
            totalBytes = 0;
            bytesReceived = 0;
            imageSize = 0;
            wordSize = 0;
            tcpServerConnection->readAll();

            QString name,password,username,productName,priceStr,productDescription;
            bool conversionOk;
            float productPrice;
            QString owner_name;
            QString shangpin_name;
            QList<std::pair<QString, QString>>result;
            int l,x;

            if(whatToDo==1){
                //表示发过来的格式是"用户名/密码",需要判断登录是否成功;返回结果为101说明登陆成功，102说明登陆失败
                //对qstr="用户名/密码"这样的字符串，可以用qstr.section('/',0,0)得到用户名，qstr.section('/',1,1)返回密码
                name=wordContent.section('/',0,0);
                password=wordContent.section('/',1,1);
                whatToDo=101;
                if(querry_password(name,password))whatToDo++;	//匹配失败
                sendMode=0;
                startTransfer();}
            else if(whatToDo==4) {
                //表示发过来的格式是"用户名/密码",需要注册, 成功返回103，失败返回104
                name=wordContent.section('/',0,0);
                password=wordContent.section('/',1,1);
                whatToDo=103;
                if(save_nameandpassword(name,password))whatToDo++;	//保存失败
                sendMode=0;
                startTransfer();}
            else if(whatToDo==2) {
                //表示发过来的格式是图片+文字,文字形如“价格/商品描述”,需要存入该商品，成功返回105，失败返回106, wordContent格式为："用户名/商品名/价格/商品描述"
                username = wordContent.section('/', 0, 0); // 提取第一部分：用户名
                productName = wordContent.section('/', 1, 1); // 提取第二部分：商品名
                priceStr = wordContent.section('/', 2, 2); // 提取第三部分：价格字符串
                productDescription = wordContent.section('/', 3, 3); // 提取第四部分：商品描述
                // 将价格字符串转换为float
                //bool conversionOk;
                productPrice = priceStr.toFloat(&conversionOk);
                if (!conversionOk) { qDebug() << "价格转换失败"; }
                whatToDo=105;
                if(save_shangpin(username,productName,productDescription,
                                  productPrice, imageContent.toUtf8()))whatToDo++;	//保存失败
                sendMode=0;
                startTransfer();}
            else if(whatToDo==3) {
                //表示发过来的是搜索的key,要进行搜索并返回搜索结果，sendMode依次为101，102，103...（感觉返回2个就可以了）
                result=keywordsearch(wordContent);
                l=result.size();
                if(l>2)l=2;
                whatToDo=100+l;	//更新whattodo
                sendMode=3;	//更新sendMode
                x=0;
                for (const auto &i:result){
                    shangpin s=querry_shangpin(i.second,i.first);
                    fileName=s.shangpin_image_location;	//更新filename
                        // 将价格从 float 转换为 QString
                    priceStr = QString::number(s.shangpin_price, 'f', 2); // 保留两位小数
                    // 使用 / 连接各个部分
                    wordsToSend=s.owner_name+"/"+s.shangpin_name+"/"+priceStr+"/"+s.shangpin_info;//更新wordstosend
                    startTransfer();	//每次更新完发送一次
                }
            }
            else if(whatToDo==6) {//删除商品，不返回
                owner_name=wordContent.section('/',0,0);
                shangpin_name=wordContent.section('/',1,1);
                if(delete_shangpin(owner_name,shangpin_name) );	//删除失败啥也不干
            }

            }

        }
    }


//这里的totalBytes、fileName变量与接收端共用了，有问题的话加新变量
void Server::startTransfer()
{

    QDataStream sendOut(&outBlock, QIODevice::WriteOnly);
    sendOut.setVersion(QDataStream::Qt_5_6);

    QByteArray wordData;
    QString imageData;

    //获得文字信息
    if(sendMode%2 ==1){
        wordData=wordsToSend.toUtf8();
        qDebug()<<wordData;
    }

    //获得图片数据
    if(sendMode/2 ==1){
        QImage image(fileName);
        imageData = getImageData(image);
    }

    //    qDebug() << "fileName: " <<fileName << "\n";


    // 保留模式信息空间、总大小信息空间、文字大小信息空间、图像大小信息空间；没有则为0
    sendOut << qint64(0)<< qint64(0) << qint64(0) << qint64(0)<< qint64(0)<<wordData<<imageData;
    //写出图文信息
    qDebug()<<wordData.size()<<imageData.size();


    totalBytes = outBlock.size();
    sendOut.device()->seek(0);

    // 返回outBolock的开始，用实际的大小信息代替四个qint64(0)空间
    sendOut <<whatToDo << sendMode <<totalBytes << qint64(wordData.size()) << qint64(2*(imageData.size()));

    //发出readyRead（）信号
    tcpServerConnection->write(outBlock);


    outBlock.resize(0);

    //ui->clientStatusLabel->setText(tr("传送文件 %1 成功").arg(currentImageName));
    //totalBytes = 0;
    //    bytesToWrite = 0;
}


//目前默认是png格式的图片，要发其他格式的应该是只需要改save函数里那个"png"就行了，但还未试过
QByteArray Server::getImageData(const QImage &image)
{
    QByteArray imageData;
    QBuffer buffer(&imageData);
    image.save(&buffer, "png");
    imageData = imageData.toBase64();
    return imageData;
}

QImage Server::getImage(const QString &data)
{
    QByteArray imageData = QByteArray::fromBase64(data.toLatin1());
    QImage image;
    image.loadFromData(imageData);
    return image;
}
//以下仅供参考，按实际ui写交互逻辑
// 开始监听按钮
void Server::on_startButton_clicked()
{
    if(ui->startButton->text() == tr("监听")){
        ui->startButton->setText(tr("断开"));
        start();
    }else{
        ui->startButton->setText(tr("监听"));
        tcpServer.close();

        tcpServerConnection->disconnectFromHost();
    }
}
